declare module "jsbarcode";
